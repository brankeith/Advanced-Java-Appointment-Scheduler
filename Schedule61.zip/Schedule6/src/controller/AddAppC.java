package controller;


import dao.AppD;
import dao.ContactD;
import dao.CustomerD;
import dao.UserD;
import helper.Globals;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import javafx.stage.Stage;
import model.Contacts;
import model.Customers;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.*;
import java.util.ResourceBundle;

    /**
     * This class creates the AddAppC controller.
     */
    public class AddAppC implements Initializable {

        Stage stage;
        Parent scene;
        public ComboBox<User> userCombo;
        public ComboBox<Customers> customerCombo;
        public ComboBox<Contacts> contactCombo;
        public ComboBox<LocalTime> startCombo;
        public ComboBox<LocalTime> endCombo;

        @FXML
        private TextField appointmentAddLocationLabel;
        @FXML
        private TextField appointmentAddTitleLabel;
        @FXML
        private TextField appointmentAddDescriptionLabel;
        @FXML
        private TextField appointmentAddTypeLabel;
        @FXML
        private DatePicker appointmentAddDatePicker;

        /**
         * This is the method to return to the Appointments screen when the user clicks the Cancel button. No inputted information is saved.
         *
         * @param event the user clicks the Cancel button on the AppointmentsAdd screen
         * @throws IOException
         */
        @FXML
        void onActionCancel(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreenAA.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        private void showAlert(Alert.AlertType alertType, String title, String content) {
            Alert alert = new Alert(alertType);
            alert.setTitle(title);
            alert.setContentText(content);
            alert.showAndWait();
        }


        /**
         * This is the method to save a new appointment when the user clicks the Save button. This method creates a new appointment using the information inputted on the AppointmentsAdd screen and inserts the new appointment into the Appointments table of the database.
         *
         * @param event the user clicks the Save button on the AppointmentsAdd screen
         */
        @FXML
        void onActionSave(ActionEvent event) {

                try {
                    // Check if the date is empty
                    if (appointmentAddDatePicker.getValue() == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "Error: The date must not be empty");
                        return;
                    }

                    // Gather field values
                    String appointmentTitle = appointmentAddTitleLabel.getText();
                    String appointmentDescription = appointmentAddDescriptionLabel.getText();
                    String appointmentLocation = appointmentAddLocationLabel.getText();
                    String appointmentType = appointmentAddTypeLabel.getText();
                    LocalTime startTime = startCombo.getSelectionModel().getSelectedItem();
                    LocalTime endTime = endCombo.getSelectionModel().getSelectedItem();

                    // Check for empty fields
                    if (appointmentTitle.isEmpty()) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The title must not be empty");
                        return;
                    }

                    if (appointmentDescription.isEmpty()) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The description must not be empty");
                        return;
                    }

                    if (appointmentLocation.isEmpty()) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The location must not be empty");
                        return;
                    }

                    if (contactCombo.getSelectionModel().getSelectedItem() == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The contact must not be empty");
                        return;
                    }

                    if (appointmentType.isEmpty()) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The type must not be empty");
                        return;
                    }

                    if (startTime == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The start time must not be empty");
                        return;
                    }

                    if (endTime == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The end time must not be empty");
                        return;
                    }

                    // Create LocalDateTime objects
                    LocalDateTime appointmentStart = LocalDateTime.of(appointmentAddDatePicker.getValue(), startTime);
                    LocalDateTime appointmentEnd = LocalDateTime.of(appointmentAddDatePicker.getValue(), endTime);

                    // Convert start and end times to Eastern Time zone for business hours check
                    ZonedDateTime startET = appointmentStart.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York"));
                    ZonedDateTime endET = appointmentEnd.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York"));

                    // Define business hours
                    LocalTime businessStart = LocalTime.of(8, 0);
                    LocalTime businessEnd = LocalTime.of(22, 0);

                    // Check if appointment is within business hours
                    if (startET.toLocalTime().isBefore(businessStart) || endET.toLocalTime().isAfter(businessEnd)) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: Appointment time must be within business hours (08:00 - 22:00 ET)!");
                        return;
                    }

                    // Check customer and user selections
                    if (customerCombo.getSelectionModel().getSelectedItem() == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The customer must not be empty");
                        return;
                    }

                    if (userCombo.getSelectionModel().getSelectedItem() == null) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The user must not be empty");
                        return;
                    }

                    int customerID = customerCombo.getValue().getCustomerId();
                    int userID = userCombo.getValue().getUserId();
                    int contactID = contactCombo.getValue().getContact_ID();
                    Timestamp createDate = Timestamp.valueOf(LocalDateTime.now());
                    String createdBy = Globals.userName;
                    Timestamp lastUpdate = Timestamp.valueOf(LocalDateTime.now());
                    String lastUpdateBy = Globals.userName;

                    if (MainC.checkOverlap(customerID, 0, appointmentStart, appointmentEnd)) {
                        showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The appointment times overlap with another appointment.");
                        return;
                    }

                    AppD.addAppointment(appointmentTitle, appointmentDescription, appointmentLocation, appointmentType, appointmentStart, appointmentEnd, createDate, createdBy, lastUpdate, lastUpdateBy, customerID, userID, contactID);
                    stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                    scene = FXMLLoader.load(getClass().getResource("/view/MainScreenAA.fxml"));
                    stage.setScene(new Scene(scene));
                    stage.show();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        /**
         * This is the method to set the combo boxes with all appropriate values.
         * @param url
         * @param resourceBundle
         */
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            try {
                userCombo.setItems(UserD.getAllUsers());
                customerCombo.setItems(CustomerD.getAllCustomers());
                contactCombo.setItems(ContactD.getAllContacts());
            } catch (Exception e) {
                e.printStackTrace();
            }

            LocalTime startStart = LocalTime.of(5,0);
            LocalTime startEnd = LocalTime.of(21,45);
            LocalTime endStart = LocalTime.of(5,15);
            LocalTime endEnd = LocalTime.of(22,0);

            while(startStart.isBefore(startEnd.plusSeconds(1))){
                startCombo.getItems().add(startStart);
                startStart = startStart.plusMinutes(15);

                while(endStart.isBefore(endEnd.plusSeconds(1))){
                    endCombo.getItems().add(endStart);
                    endStart = endStart.plusMinutes(15);
                }
            }
        }
    }


