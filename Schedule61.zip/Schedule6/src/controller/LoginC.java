package controller;

import dao.AppD;
import Alert.Alerts;
import dao.UserD;
import helper.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.User;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.TimeZone;

import java.io.*;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This class creates the LoginC controller.
 */
public class LoginC implements Initializable {

    ResourceBundle myBundle = ResourceBundle.getBundle("bundle/lang");
    TimeZone tz = TimeZone.getDefault();
    String tz1 = tz.getID();

    @FXML
    private TextField usernameTxt;
    @FXML
    private PasswordField passwordTxt;
    @FXML
    private Label userNameLabel;
    @FXML
    private Label titleLabel;

    @FXML
    private Label passwordLabel;
    @FXML
    private Label locationLabel;
    @FXML
    private Button loginButton;
    @FXML
    private Button exitButton;

    /**
     * This method exits the program when the user clicks the Exit button
     *
     * @param event the user clicks the Exit button
     */
    @FXML
    void onActionExit(ActionEvent event) {
        Locale locale;
        if (TimeZone.getDefault().getID().equals("Etc/UTC")) {
            locale = new Locale("fr", "FR");
        } else {
            locale = Locale.getDefault();
        }
        ResourceBundle resourceBundle1 = ResourceBundle.getBundle("Bundle/lang", locale);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, resourceBundle1.getString("Exit"));
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            JDBC.closeConnection();
            System.exit(0);
        }
    }

    /**
     * This lambda indicates that no username was provided at the timestamp.
     */
    public Alerts messageNoUser = s -> {
        return "No username provided at " + s;
    };

    /**
     * This method receives the user inputted username and password when the user clicks the Log In button. This method validates that the username and password are not empty and then validates the username and password combo with the records in the Users table of the database.
     *
     * @param event the user clicks the Log In button
     * @throws Exception
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    void onActionLogIn(ActionEvent event) throws Exception, SQLException, IOException {
        String User_Name = usernameTxt.getText();
        String Password = passwordTxt.getText();
        String filename = "login_activity.txt";
        File file = new File(filename);

        try (FileWriter fwriter = new FileWriter(file, true); PrintWriter outputFile = new PrintWriter(fwriter)) {
            LocalDateTime time = LocalDateTime.now();
            ZonedDateTime LDTConvert = time.atZone(ZoneId.systemDefault());
            ZonedDateTime LDTUTC = LDTConvert.withZoneSameInstant(ZoneId.of("Etc/UTC"));
            Locale locale;
            if (TimeZone.getDefault().getID().equals("Etc/UTC")) {
                locale = new Locale("fr", "FR");
            } else {
                locale = Locale.getDefault();
            }
            ResourceBundle resourceBundle1 = ResourceBundle.getBundle("Bundle/lang", locale);

            if (User_Name.isEmpty() || User_Name.isBlank() || Password.isEmpty() || Password.isBlank()) {
                String message = (User_Name.isEmpty() || User_Name.isBlank()) ? messageNoUser.getMessage(LDTUTC.toString()) : "User " + User_Name + " failed login at " + LDTUTC;
                outputFile.println(message);

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle(resourceBundle1.getString("WarningDialog"));
                alert.setContentText(resourceBundle1.getString("ERROR"));
                alert.showAndWait();
                return;
            }

            if (UserD.validateLogIn(User_Name, Password)) {
                successfulLoginHandling(User_Name, outputFile, LDTUTC, event);
            } else {
                outputFile.println("User " + User_Name + " failed login at " + LDTUTC);

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle(myBundle.getString("WarningDialog"));
                alert.setContentText(myBundle.getString("ERROR"));
                alert.showAndWait();
            }
        }
    }

    /**
     * Handles the logic after a successful login by the user.
     * This includes checking for any appointments within the next 15 minutes
     * and navigating to the main screen.
     *
     * @param User_Name  The username of the logged-in user.
     * @param outputFile A PrintWriter object to log the login activity.
     * @param LDTUTC     The login time in UTC.
     * @param event      The ActionEvent triggering this method.
     * @throws Exception Throws an exception if an error occurs during execution.
     */
    private void successfulLoginHandling(String User_Name, PrintWriter outputFile, ZonedDateTime LDTUTC, ActionEvent event) throws Exception {
        User userResult = UserD.getUser(User_Name);
        Globals.userName = userResult.getUserName();
        int userID = UserD.getUserIDFromUserName(Globals.userName);

        LocalDateTime nowLDT = LocalDateTime.now();
        LocalDateTime plus15LDT = nowLDT.plusMinutes(15);
        ObservableList<Appointments> scheduledAppts = FXCollections.observableArrayList();
        ObservableList<Appointments> appointments = AppD.getAppointmentUserID(userID);
        Locale locale;
        if (TimeZone.getDefault().getID().equals("Etc/UTC")) {
            locale = new Locale("fr", "FR");
        } else {
            locale = Locale.getDefault();
        }
        ResourceBundle resourceBundle1 = ResourceBundle.getBundle("Bundle/lang", locale);

        if (appointments != null) {
            for (Appointments appointment : appointments) {
                if ((appointment.getStart().isAfter(nowLDT) || appointment.getStart().isEqual(nowLDT)) && (appointment.getStart().isBefore(plus15LDT) || appointment.getStart().isEqual(plus15LDT))) {
                    scheduledAppts.add(appointment);
                    if (scheduledAppts.size() > 0) {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle(resourceBundle1.getString("WarningDialog"));
                        alert.setContentText(resourceBundle1.getString("NoticeAppt") + appointment.getAppointment_ID() + " " + resourceBundle1.getString("At") + appointment.getStart() + " " + resourceBundle1.getString("StartsSoon"));
                        alert.showAndWait();
                    }
                }
            }
            if (scheduledAppts.size() < 1) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle(resourceBundle1.getString("WarningDialog"));
                alert.setContentText(resourceBundle1.getString("NoAppointments"));
                alert.showAndWait();
            }
        }
        outputFile.println("User " + User_Name + " successfully logged in at " + LDTUTC);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainScreenAA.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


    /**
     * This is the method to set the user's location and set the text on the Log In page in either English or French depending on the user's location.
     *
     * @param url
     * @param resourceBundle
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        locationLabel.setText(tz1);
        Locale locale;
        if (TimeZone.getDefault().getID().equals("Etc/UTC")) {
            locale = new Locale("fr", "FR");
        } else {
            locale = Locale.getDefault();
        }
        ResourceBundle resourceBundle1 = ResourceBundle.getBundle("Bundle/lang", locale);
        userNameLabel.setText(resourceBundle1.getString("Username"));
        passwordLabel.setText(resourceBundle1.getString("Password"));
        loginButton.setText(resourceBundle1.getString("Login"));
        exitButton.setText(resourceBundle1.getString("ExitButton"));
        titleLabel.setText(resourceBundle1.getString("Title"));
    }
}
