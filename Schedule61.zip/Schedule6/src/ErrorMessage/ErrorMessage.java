package ErrorMessage;

public interface ErrorMessage {


        String getErrorMessage(String s);
    }


