TITLE:                                                                      Appointment Assistant
PURPOSE OF THE APPLICATION:                                                 A desktop application with a graphical user interface designed for schedule management, featuring filter capabilities to manage and maintain a comprehensive database of customers and their respective appointments.
AUTHOR:                                                                     Brandon Keith
CONTACT INFORMATION:                                                        bcoun15@wgu.edu
                                                                            (910) 728-8011
STUDENT APPLICATION VERSION:                                                1.0
DATE:                                                                       March 17, 2024
IDE (INCLUDING VERSION NUMBER):                                             JetBrains IntelliJ IDEA Community Edition 2022.1.4
FULL JDK VERSION USED:                                                      Java SE 17.0.1
JAVAFX VERSION COMPATIBLE WITH JDK VERSION:                                 JavaFX-SDK-17.0.1
DIRECTIONS FOR HOW TO RUN THE PROGRAM:                                      Launch application and login with one of the following:
                                                                            Username "test" and password "test"
                                                                            Username "admin" and password "admin"
A DESCRIPTION OF THE ADDITIONAL REPORT OF YOUR CHOICE YOU RAN IN PART A3F:  An added reporting feature enables the user to choose a country from a drop-down menu, after which the report counts the total number of customers located in the selected nation.
THE MYSQL CONNECTOR DRIVER VERSION NUMBER, INCLUDING THE UPDATE NUMBER:     mysql-connector-java-8.0.25