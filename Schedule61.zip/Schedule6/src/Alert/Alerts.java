package Alert;

public interface Alerts {

    String getMessage(String s);

}
