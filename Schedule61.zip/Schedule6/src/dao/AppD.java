package dao;

import helper.JDBC;
import helper.Query;
import model.AppointmentT;
import model.Appointments;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * This class creates the Appointment database methods.
 */
public class AppD {
    /**
     * This is the method to create an ObservableList of appointments containing the User ID. This method executes an SQL query to find all appointments containing the User ID and then adds the appointments to the ObservableList userIDAppointments.
     * @param userID the userID to get the appointment of
     * @return the ObservableList userIDAppointments containing appointments with the User ID
     * @throws SQLException
     * @throws Exception
     */
    public static ObservableList<Appointments> getAppointmentUserID(int userID) throws SQLException, Exception{
        ObservableList<Appointments> userIDAppointments=FXCollections.observableArrayList();
        String sqlStatement="select * FROM Appointments WHERE User_ID  = '" + userID + "'";
        Query.makeQuery(sqlStatement);
        Appointments appointmentResult;
        ResultSet result=Query.getResult();
        while(result.next()){
            int Appointment_ID=result.getInt("Appointment_ID");
            String Title=result.getString("Title");
            String Description=result.getString("Description");
            String Location=result.getString("Location");
            String Type=result.getString("Type");
            Timestamp Start=result.getTimestamp("Start");
            LocalDateTime StartCalendar=Start.toLocalDateTime();
            Timestamp End=result.getTimestamp("End");
            LocalDateTime EndCalendar=End.toLocalDateTime();
            Timestamp Create_Date=result.getTimestamp("Create_Date");
            LocalDateTime Create_DateCalendar=Create_Date.toLocalDateTime();
            String Created_By=result.getString("Created_By");
            Timestamp Last_Update=result.getTimestamp("Last_Update");
            LocalDateTime Last_UpdateCalendar=Last_Update.toLocalDateTime();
            String Last_Updated_By=result.getString("Last_Updated_By");
            int Customer_ID=result.getInt("Customer_ID");
            int User_ID=result.getInt("User_ID");
            int Contact_ID=result.getInt("Contact_ID");

            appointmentResult= new Appointments(Appointment_ID, Title, Description, Location, Type, StartCalendar, EndCalendar, Create_DateCalendar, Created_By, Last_UpdateCalendar, Last_Updated_By, Customer_ID, User_ID, Contact_ID);
            userIDAppointments.add(appointmentResult);
        }
        return userIDAppointments;
    }

    /**
     * This is the method to create an ObservableList to get all appointments. This method executes an SQL query to find all appointments and then adds the appointments to the ObservableList allAppointments.
     * @return the ObservableList allAppointments with all appointments
     * @throws SQLException
     * @throws Exception
     */
    public static ObservableList<Appointments> getAllAppointments() throws SQLException, Exception{
        ObservableList<Appointments> allAppointments=FXCollections.observableArrayList();
        String sqlStatement="select * from Appointments";
        Query.makeQuery(sqlStatement);
        ResultSet result=Query.getResult();
        while(result.next()){
            int Appointment_ID=result.getInt("Appointment_ID");
            String Title=result.getString("Title");
            String Description=result.getString("Description");
            String Location=result.getString("Location");
            String Type=result.getString("Type");
            Timestamp Start=result.getTimestamp("Start");
            LocalDateTime StartCalendar=Start.toLocalDateTime();
            Timestamp End=result.getTimestamp("End");
            LocalDateTime EndCalendar=End.toLocalDateTime();
            Timestamp Create_Date=result.getTimestamp("Create_Date");
            LocalDateTime Create_DateCalendar=Create_Date.toLocalDateTime();
            String Created_By=result.getString("Created_By");
            Timestamp Last_Update=result.getTimestamp("Last_Update");
            LocalDateTime Last_UpdateCalendar=Last_Update.toLocalDateTime();
            String Last_Updated_By=result.getString("Last_Updated_By");
            int Customer_ID=result.getInt("Customer_ID");
            int User_ID=result.getInt("User_ID");
            int Contact_ID=result.getInt("Contact_ID");

            Appointments appointmentResult= new Appointments(Appointment_ID, Title, Description, Location, Type, StartCalendar, EndCalendar, Create_DateCalendar, Created_By, Last_UpdateCalendar, Last_Updated_By, Customer_ID, User_ID, Contact_ID);
            allAppointments.add(appointmentResult);
        }
        return allAppointments;
    }

    /**
     * This is the method to add an appointment. The method executes an SQL query to insert a new Appointment into the Appointments table of the database using the data inputted on the AppointmentsAdd screen.
     * @param appointmentTitle the title of the appointment to add
     * @param appointmentDescription the description of the appointment to add
     * @param appointmentLocation the location of the appointment to add
     * @param appointmentType the type of the appointment to add
     * @param appointmentStart the start of the appointment to add
     * @param appointmentEnd the end of the appointment to add
     * @param createDate the create date of the appointment to add
     * @param createdBy the user creating the appointment to add
     * @param lastUpdate the last updated time of the appointment to add
     * @param lastUpdateBy the last user to update the appointment to add
     * @param customerID the customer ID of the appointment to add
     * @param userID the user ID of the appointment to add
     * @param contactID the contact ID of the appointment to add
     */
    public static void addAppointment(String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType, LocalDateTime appointmentStart, LocalDateTime appointmentEnd, Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdateBy, int customerID, int userID, int contactID) {
        try{
            String sql = "INSERT INTO appointments(Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psti = JDBC.connection.prepareStatement(sql);

            psti.setString(1, appointmentTitle);
            psti.setString(2, appointmentDescription);
            psti.setString(3, appointmentLocation);
            psti.setString(4, appointmentType);
            psti.setTimestamp(5, Timestamp.valueOf(appointmentStart));
            psti.setTimestamp(6, Timestamp.valueOf(appointmentEnd));
            psti. setTimestamp(7, createDate);
            psti.setString(8, createdBy);
            psti.setTimestamp(9, lastUpdate);
            psti.setString(10, lastUpdateBy);
            psti.setInt(11, customerID);
            psti.setInt(12, userID);
            psti.setInt(13, contactID);

            psti.execute();
        } catch(SQLException ex){
            ex.printStackTrace();
        }
    }

    /**
     * This is the method to modify an appointment. The method executes an SQL query to update an existing Appointment in the Appointments table of the database using the data inputted on the AppointmentsModify screen.
     * @param appointmentID the ID of the appointment to modify
     * @param appointmentTitle the title of the appointment to modify
     * @param appointmentDescription the description of the appointment to modify
     * @param appointmentLocation the location of the appointment to modify
     * @param appointmentType the type of the appointment to modify
     * @param appointmentStart the start time of the appointment to modify
     * @param appointmentEnd the end time of the appointment to modify
     * @param lastUpdate the last updated time of the appointment to modify
     * @param lastUpdateBy the last user to update the appointment to modify
     * @param customerID the customer ID of the appointment to modify
     * @param userID the user ID of the appointment to modify
     * @param contactID the contact ID of the appointment to modify
     */
    public static void modifyAppointment(int appointmentID, String appointmentTitle, String appointmentDescription, String appointmentLocation, String appointmentType, LocalDateTime appointmentStart, LocalDateTime appointmentEnd, Timestamp lastUpdate, String lastUpdateBy, int customerID, int userID, int contactID) {
        try{
            String sql2 = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Last_Update = ?, Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
            PreparedStatement ps1 = JDBC.connection.prepareStatement(sql2);

            ps1.setString(1, appointmentTitle);
            ps1.setString(2, appointmentDescription);
            ps1.setString(3, appointmentLocation);
            ps1. setString(4, appointmentType);
            ps1.setTimestamp(5, Timestamp.valueOf(appointmentStart));
            ps1.setTimestamp(6, Timestamp.valueOf(appointmentEnd));
            ps1.setTimestamp(7, lastUpdate);
            ps1.setString(8, lastUpdateBy);
            ps1.setInt(9, customerID);
            ps1.setInt(10, userID);
            ps1.setInt(11, contactID);
            ps1.setInt(12, appointmentID);

            ps1.execute();
        } catch(SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * This is the method to delete an appointment. The method executes an SQL query to delete an existing Appointment in the Appointments table of the database with the selected Appointment ID.
     * @param appointmentID the ID of the appointment to delete
     */
    public static void deleteAppointment(int appointmentID) {
        try {
            String sql3= "DELETE FROM appointments WHERE Appointment_ID = ?";
            PreparedStatement ps2 = JDBC.connection.prepareStatement(sql3);

            ps2.setInt(1, appointmentID);

            ps2.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * This is the method to delete an appointment when a customer is deleted. The method executes an SQL query to delete an existing Appointment in the Appointments table of the database with the selected Customer ID.
     * @param customerID the ID of the customer being deleted
     * @param appointmentID the ID of the appointment to delete
     */
    public static void deleteApptCustID(int customerID, int appointmentID) {
        try {
            String sql4 = "DELETE FROM appointments WHERE Customer_ID = ? AND Appointment_ID = ?";
            PreparedStatement ps3 = JDBC.connection.prepareStatement(sql4);

            ps3.setInt(1, customerID);
            ps3.setInt(2, appointmentID);

            ps3.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * This is the method to create the ObservableList typeAppt with only the distinct appointment types. The method executes an SQL query to select only the distinct Type strings from the Appointments table.
     * @return the ObservableList typeAppt with only the distinct appointment types
     * @throws SQLException
     */
    public static ObservableList<AppointmentT> typeAppt() throws SQLException {
        ObservableList<AppointmentT> typeAppt=FXCollections.observableArrayList();
        String sqlStatement = "select distinct Type from appointments";
        Query.makeQuery(sqlStatement);
        ResultSet result=Query.getResult();
        while(result.next()){
            String Type=result.getString("Type");

            AppointmentT appointmentTypeResult= new AppointmentT(Type);
            typeAppt.add(appointmentTypeResult);
        }
        return typeAppt;
    }

    /**
     * This is the method to count the number of appointments with both the selected type and the selected month. The method executes an SQL query to count from the Appointments table where the selected type and the selected month are in an appointment.
     * @param selectedType the type of appointment to count
     * @param month the month for which to count
     * @return the number of appointments with both the selected type and the selected month
     * @throws SQLException
     */
    public static int countMonthType(AppointmentT selectedType, String month) throws SQLException {
        String sqlStatement = "SELECT COUNT(*) AS monthType FROM appointments WHERE Type  = '" + selectedType + "' AND MONTHNAME(Start) = '" + month + "'";
        Query.makeQuery(sqlStatement);
        int countMonthTypeResult = 0;
        ResultSet result = Query.getResult();
        while(result.next()) {
            countMonthTypeResult = result.getInt("monthType");

            return countMonthTypeResult;
        }
        return countMonthTypeResult;
    }

    /**
     * The Lambda filters appointments based on Contact ID
     * @param selectedContactID the contact ID by which to filter appointments
     * @return the ObservableList contactList of appointments containing the Contact ID
     * @throws SQLException
     * @throws Exception
     */
    public static ObservableList<Appointments> getAppointmentsContactID(int selectedContactID) throws SQLException, Exception{
        ObservableList<Appointments> allAppointments = getAllAppointments();
        ObservableList<Appointments> contactList = allAppointments.filtered(a -> {
            if (a.getContact_ID() == selectedContactID){
                return true;
            }
            return false;
        });
        return contactList;
    }

    /**
     * This is the method to create the ObservableList currentMonthAppointments with only appointments with start timestamps within the current month. The method executes an SQL query to select only appointments in the Appointments table where the month of the start attribute matches the current month.
     * @return the ObservableList currentMonthAppointments of appointments this month
     * @throws SQLException
     * @throws Exception
     */
    public static ObservableList<Appointments> getCurrentMonthAppointments() throws SQLException, Exception{
        ObservableList<Appointments> currentMonthAppointments=FXCollections.observableArrayList();
        String sqlStatement="select * from Appointments where MONTH(Start) = MONTH(CURDATE())";
        Query.makeQuery(sqlStatement);
        ResultSet result=Query.getResult();
        while(result.next()){
            int Appointment_ID=result.getInt("Appointment_ID");
            String Title=result.getString("Title");
            String Description=result.getString("Description");
            String Location=result.getString("Location");
            String Type=result.getString("Type");
            Timestamp Start=result.getTimestamp("Start");
            LocalDateTime StartCalendar=Start.toLocalDateTime();
            Timestamp End=result.getTimestamp("End");
            LocalDateTime EndCalendar=End.toLocalDateTime();
            Timestamp Create_Date=result.getTimestamp("Create_Date");
            LocalDateTime Create_DateCalendar=Create_Date.toLocalDateTime();
            String Created_By=result.getString("Created_By");
            Timestamp Last_Update=result.getTimestamp("Last_Update");
            LocalDateTime Last_UpdateCalendar=Last_Update.toLocalDateTime();
            String Last_Updated_By=result.getString("Last_Updated_By");
            int Customer_ID=result.getInt("Customer_ID");
            int User_ID=result.getInt("User_ID");
            int Contact_ID=result.getInt("Contact_ID");

            Appointments appointmentResult= new Appointments(Appointment_ID, Title, Description, Location, Type, StartCalendar, EndCalendar, Create_DateCalendar, Created_By, Last_UpdateCalendar, Last_Updated_By, Customer_ID, User_ID, Contact_ID);
            currentMonthAppointments.add(appointmentResult);
        }
        return currentMonthAppointments;
    }

    /**
     * This is the method to create the ObservableList currentWeekAppointments with only appointments with start timestamps within the current week. The method executes an SQL query to select only appointments in the Appointments table where the week of the start attribute matches the current week.
     * @return the ObservableList currentWeekAppointments of appointments this week
     * @throws SQLException
     * @throws Exception
     */
    public static ObservableList<Appointments> getCurrentWeekAppointments() throws SQLException, Exception{
        ObservableList<Appointments> currentWeekAppointments=FXCollections.observableArrayList();
        String sqlStatement="select * from Appointments where WEEK(Start) = WEEK(CURDATE())";
        Query.makeQuery(sqlStatement);
        ResultSet result=Query.getResult();
        while(result.next()){
            int Appointment_ID=result.getInt("Appointment_ID");
            String Title=result.getString("Title");
            String Description=result.getString("Description");
            String Location=result.getString("Location");
            String Type=result.getString("Type");
            Timestamp Start=result.getTimestamp("Start");
            LocalDateTime StartCalendar=Start.toLocalDateTime();
            Timestamp End=result.getTimestamp("End");
            LocalDateTime EndCalendar=End.toLocalDateTime();
            Timestamp Create_Date=result.getTimestamp("Create_Date");
            LocalDateTime Create_DateCalendar=Create_Date.toLocalDateTime();
            String Created_By=result.getString("Created_By");
            Timestamp Last_Update=result.getTimestamp("Last_Update");
            LocalDateTime Last_UpdateCalendar=Last_Update.toLocalDateTime();
            String Last_Updated_By=result.getString("Last_Updated_By");
            int Customer_ID=result.getInt("Customer_ID");
            int User_ID=result.getInt("User_ID");
            int Contact_ID=result.getInt("Contact_ID");

            Appointments appointmentResult= new Appointments(Appointment_ID, Title, Description, Location, Type, StartCalendar, EndCalendar, Create_DateCalendar, Created_By, Last_UpdateCalendar, Last_Updated_By, Customer_ID, User_ID, Contact_ID);
            currentWeekAppointments.add(appointmentResult);
        }
        return currentWeekAppointments;
    }

    /**
     * This is the method to count the number of appointments with the selected Customer ID. The method executes an SQL query to count from the Appointments table where the selected Customer ID is in an appointment.
     * @param customerID the customer ID to count appointments for
     * @return the number of appointments containing the Customer ID
     * @throws SQLException
     */
    public static int countCustAppt(int customerID) throws SQLException {
        String sqlStatement = "SELECT COUNT(*) AS custAppt FROM appointments WHERE Customer_ID  = '" + customerID + "'";
        Query.makeQuery(sqlStatement);
        int countCustApptResult = 0;
        ResultSet result = Query.getResult();
        while(result.next()) {
            countCustApptResult = result.getInt("custAppt");

            return countCustApptResult;
        }
        return countCustApptResult;
    }
}