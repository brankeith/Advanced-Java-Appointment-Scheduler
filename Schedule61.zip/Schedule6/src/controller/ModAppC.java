package controller;

import dao.AppD;
import dao.ContactD;
import dao.CustomerD;
import dao.UserD;
import helper.Globals;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Customers;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ResourceBundle;

    /**
     * This class creates the ModAppC controller.
     */
    public class ModAppC implements Initializable {

        Stage stage;
        Parent scene;
        private static Appointments selectedAppointment;

        @FXML
        private TextField appointmentModifyIDLabel;
        @FXML private ComboBox<Contacts> appointmentModifyContactCombo;
        @FXML private TextField appointmentModifyLocationLabel;
        @FXML private TextField appointmentModifyTitleLabel;
        @FXML private TextField appointmentModifyDescriptionLabel;
        @FXML private TextField appointmentModifyTypeLabel;
        @FXML private DatePicker appointmentModifyDatePicker;
        @FXML private ComboBox<LocalTime> appointmentModifyStartCombo;
        @FXML private ComboBox<LocalTime> appointmentModifyEndCombo;
        @FXML private ComboBox<Customers> appointmentModifyCustomerIDCombo;
        @FXML private ComboBox<User> appointmentModifyUserIDCombo;

        /**
         * This is the method to return to the Appointments screen when the user clicks the Cancel button. No inputted information is saved.
         * @param event the user clicks the Cancel button
         * @throws IOException
         */
        @FXML void onActionBack(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/MainScreenAA.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

        /**
         * Displays an alert dialog to the user.
         * @param alertType Type of alert (e.g., WARNING, CONFIRMATION).
         * @param title Title of the alert dialog.
         * @param content The message to display in the alert dialog.
         */
        private void showAlert(Alert.AlertType alertType, String title, String content) {
            Alert alert = new Alert(alertType);
            alert.setTitle(title);
            alert.setContentText(content);
            alert.showAndWait();
        }
        /**
         * Saves the modified appointment details to the database.
         * This method validates input fields, checks for logical errors, and updates the appointment information.
         * @param event The event that triggered this method (click on the Save button).
         */
        @FXML
        void onActionSave(ActionEvent event) {
            try {
                if (appointmentModifyDatePicker.getValue() == null) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The date must not be empty");
                    return;
                }

                String appointmentTitle = appointmentModifyTitleLabel.getText();
                String appointmentDescription = appointmentModifyDescriptionLabel.getText();
                String appointmentLocation = appointmentModifyLocationLabel.getText();
                String appointmentType = appointmentModifyTypeLabel.getText();
                LocalTime startTime = appointmentModifyStartCombo.getSelectionModel().getSelectedItem();
                LocalTime endTime = appointmentModifyEndCombo.getSelectionModel().getSelectedItem();

                if (appointmentTitle.isEmpty() || appointmentDescription.isEmpty() || appointmentLocation.isEmpty() || appointmentType.isEmpty() || startTime == null || endTime == null) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: All fields must be filled out and times selected");
                    return;
                }

                if (appointmentModifyContactCombo.getSelectionModel().getSelectedItem() == null ||
                        appointmentModifyCustomerIDCombo.getSelectionModel().getSelectedItem() == null ||
                        appointmentModifyUserIDCombo.getSelectionModel().getSelectedItem() == null) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: Please make a selection for all dropdowns");
                    return;
                }

                LocalDateTime appointmentStart = LocalDateTime.of(appointmentModifyDatePicker.getValue(), startTime);
                LocalDateTime appointmentEnd = LocalDateTime.of(appointmentModifyDatePicker.getValue(), endTime);

                if (!appointmentStart.isBefore(appointmentEnd)) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: Appointment start time must be before end time!");
                    return;
                }

                ZonedDateTime startZoned = appointmentStart.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York"));
                ZonedDateTime endZoned = appointmentEnd.atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("America/New_York"));
                if (startZoned.toLocalTime().isBefore(LocalTime.of(8, 0)) || endZoned.toLocalTime().isAfter(LocalTime.of(22, 0))) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: Appointment must be within business hours (8 AM to 10 PM EST)!");
                    return;
                }

                int customerID = appointmentModifyCustomerIDCombo.getValue().getCustomerId();
                int appointmentID = Integer.parseInt(appointmentModifyIDLabel.getText()); // Assuming this is for modifying an existing appointment
                if (MainC.checkOverlap(customerID, appointmentID, appointmentStart, appointmentEnd)) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: This appointment overlaps with another appointment.");
                    return;
                }


                int userID = appointmentModifyUserIDCombo.getValue().getUserId();
                int contactID = appointmentModifyContactCombo.getValue().getContact_ID();
                Timestamp lastUpdate = Timestamp.valueOf(LocalDateTime.now());
                String lastUpdateBy = Globals.userName;

                AppD.modifyAppointment(appointmentID, appointmentTitle, appointmentDescription, appointmentLocation, appointmentType, appointmentStart, appointmentEnd, lastUpdate, lastUpdateBy, customerID, userID, contactID);
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/MainScreenAA.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        /**
         * This method takes the appointment selected on the Appointments screen to be modified and sends the appointment data to the fields on the AppointmentsModify screen.
         * @param appointment the selected existing appointment being received to modify
         */
        public static void receiveSelectedAppointment(Appointments appointment){
            selectedAppointment = appointment;
        }

        /**
         * This is the method to set the combo boxes with all appropriate values, set the combo boxes to select the data from the modified appointment, and populate all fields with the data from the modified appointment.
         * @param url
         * @param resourceBundle
         */
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            try{
                appointmentModifyContactCombo.setValue(ContactD.getContactFromContactID(selectedAppointment.getContact_ID()));
                appointmentModifyContactCombo.setItems(ContactD.getAllContacts());
                appointmentModifyCustomerIDCombo.setValue(CustomerD.getCustomerFromCustomerID(selectedAppointment.getCustomer_ID()));
                appointmentModifyCustomerIDCombo.setItems(CustomerD.getAllCustomers());
                appointmentModifyUserIDCombo.setValue(UserD.getUserFromUserID(selectedAppointment.getUser_ID()));
                appointmentModifyUserIDCombo.setItems(UserD.getAllUsers());
            } catch (Exception throwables) {
                throwables.printStackTrace();
            }

            LocalTime startStart = LocalTime.of(5,0);
            LocalTime startEnd = LocalTime.of(21,45);
            LocalTime endStart = LocalTime.of(5,15);
            LocalTime endEnd = LocalTime.of(22,0);

            while(startStart.isBefore(startEnd.plusSeconds(1))){
                appointmentModifyStartCombo.getItems().add(startStart);
                startStart = startStart.plusMinutes(15);

                while(endStart.isBefore(endEnd.plusSeconds(1))){
                    appointmentModifyEndCombo.getItems().add(endStart);
                    endStart = endStart.plusMinutes(15);
                }
            }

            appointmentModifyIDLabel.setText(Integer.toString(selectedAppointment.getAppointment_ID()));
            appointmentModifyTitleLabel.setText(selectedAppointment.getTitle());
            appointmentModifyDescriptionLabel.setText(selectedAppointment.getDescription());
            appointmentModifyLocationLabel.setText(selectedAppointment.getLocation());
            appointmentModifyTypeLabel.setText(selectedAppointment.getType());
            appointmentModifyDatePicker.setValue(selectedAppointment.getStart().toLocalDate());
            appointmentModifyStartCombo.setValue(selectedAppointment.getStart().toLocalTime());
            appointmentModifyEndCombo.setValue(selectedAppointment.getEnd().toLocalTime());
        }
    }


