package main;

import helper.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/** Brandon Keith
 * The Main is the main class and entry point for the application
 */

public class Main extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/LoginAA.fxml" ));
        stage.setTitle("Appointment Assistant");
        stage.setScene(new Scene(root));
        stage.show();
    }

    public static void main(String [] args){
        JDBC.openConnection();
        launch(args);
        JDBC.closeConnection();
    }
}
