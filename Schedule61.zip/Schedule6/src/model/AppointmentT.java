package model;

/**
 * Represents an appointment type in the system.
 * This class encapsulates the type of appointments, allowing for easy management and retrieval of different appointment types within the application.
 */
public class AppointmentT {

        private String Type;

        public AppointmentT(String Type){
            this.Type = Type;
        }

        /**
         * @return the appointmentType type
         */
        public String getType() {
            return Type;
        }

        /**
         * @param Type the appointmentType type to set
         */
        public void setType(String Type) {
            Type = Type;
        }

        /**
         * @return the appointmentType String type
         */
        @Override
        public String toString(){return Type;}
    }

