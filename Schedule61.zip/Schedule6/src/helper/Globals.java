package helper;

public class Globals {
    public static String userName;
}