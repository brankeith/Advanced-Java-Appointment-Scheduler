package controller;

import dao.AppD;
import dao.ContactD;
import dao.CountryD;
import dao.CustomerD;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class creates the Reports controller.
 */
public class RepoC implements Initializable {

    Stage stage;
    Parent scene;
    ObservableList<model.Appointments> Appointment = FXCollections.observableArrayList();
    ObservableList<String> Months = FXCollections.observableList(Arrays.asList("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"));

    @FXML private ComboBox<String> monthCombo;
    @FXML private ComboBox<AppointmentT> typeCombo;
    @FXML private Label appointmentsTotalLabel;
    @FXML private ComboBox<Contacts> contactCombo;
    @FXML private ComboBox<Country> countryCombo;
    @FXML private Label customersTotalLabel;
    @FXML private TableView<Appointments> AppointmentTable;
    @FXML private TableColumn<Appointments, Integer> Appointment_ID;
    @FXML private TableColumn<Appointments, String> Title;
    @FXML private TableColumn<Appointments, String> Description;
    @FXML private TableColumn<Appointments, String> Location;
    @FXML private TableColumn<Appointments, Integer> Contact;
    @FXML private TableColumn<Appointments, String> Type;
    @FXML private TableColumn<Appointments, Calendar> Start;
    @FXML private TableColumn<Appointments, Calendar> End;
    @FXML private TableColumn<Appointments, Integer> Customer_ID;
    @FXML private TableColumn<Appointments, Integer> User_ID;

    /**
     * This is the method to display the count of the number of customers per country when the user selects a country from the countryCombo combo box.
     * @param event the user selects a country from the countryCombo combo box
     * @throws SQLException
     */
    @FXML void onActionCountryCombo(ActionEvent event) throws SQLException {
        Country selectedCountry = countryCombo.getValue();
        int selectedCountryID = selectedCountry.getCountry_ID();
        customersTotalLabel.setText(String.valueOf(CustomerD.countCustomers(selectedCountryID)));
    }


    @FXML void onActionBack(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/MainScreenAA.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**
     * This is the method to display the count of the selected type of appointments in the already selected month when the user selects an appointmentType from the typeCombo combo box.
     * @param event the user selects a type from the typeCombo combo box
     * @throws SQLException
     */
    @FXML void onActionTypeCombo(ActionEvent event) throws SQLException {
        AppointmentT selectedType = typeCombo.getValue();
        String selectedMonth = monthCombo.getValue();
        appointmentsTotalLabel.setText(String.valueOf(AppD.countMonthType(selectedType, selectedMonth)));
    }

    /**
     * This is the method to display the count of the already selected type of appointments in the selected month when the user selects a month from the monthCombo combo box.
     * @param event the user selects a month from the monthCombo combo box
     * @throws SQLException
     */
    @FXML void onActionMonthCombo(ActionEvent event) throws SQLException {
        AppointmentT selectedType = typeCombo.getValue();
        String selectedMonth = monthCombo.getValue();
        appointmentsTotalLabel.setText(String.valueOf(AppD.countMonthType(selectedType, selectedMonth)));
    }

    /**
     * This is the method to display the appointments for the selected contact when the user selects a contact from the contactCombo combo box.
     * @param event the user selects a contact from the contactCombo combo box
     */
    @FXML void onActionContactCombo(ActionEvent event) {
        Appointment.clear();
        Contacts selectedContact = contactCombo.getValue();
        int selectedContactID = selectedContact.getContact_ID();

        try {
            Appointment.addAll(AppD.getAppointmentsContactID(selectedContactID));
        } catch (Exception ex) {
            Logger.getLogger(Appointments.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This is the method to set the combo boxes and set the AppointmentTable from the Appointments table in the database.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            contactCombo.setItems(ContactD.getAllContacts());
            countryCombo.setItems(CountryD.getAllCountries());
            typeCombo.setItems(AppD.typeAppt());
            monthCombo.setItems(Months);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Appointment_ID.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        Title.setCellValueFactory(new PropertyValueFactory<>("Title"));
        Description.setCellValueFactory(new PropertyValueFactory<>("Description"));
        Location.setCellValueFactory(new PropertyValueFactory<>("Location"));
        Contact.setCellValueFactory(new PropertyValueFactory<>("Contact_ID"));
        Type.setCellValueFactory(new PropertyValueFactory<>("Type"));
        Start.setCellValueFactory(new PropertyValueFactory<>("Start"));
        End.setCellValueFactory(new PropertyValueFactory<>("End"));
        Customer_ID.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        User_ID.setCellValueFactory(new PropertyValueFactory<>("User_ID"));
        AppointmentTable.setItems(Appointment);
    }
}
