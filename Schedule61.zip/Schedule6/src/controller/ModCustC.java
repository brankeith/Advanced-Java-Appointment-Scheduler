package controller;

import ErrorMessage.ErrorMessage;
import dao.CountryD;
import dao.CustomerD;
import dao.DivisionD;
import helper.Globals;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Country;
import model.Customers;
import model.FLD;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

    /**
     * This class creates the ModCustC controller.
     */
    public class ModCustC implements Initializable {

        Stage stage;
        Parent scene;
        private static Customers selectedCustomer;
        private static int selectedCountryID;
        private static Country selectedCountry;

        @FXML
        private ComboBox<FLD> divisionCombo;

        @FXML private ComboBox<Country> countryCombo;
        @FXML private TextField customersModifyIDLabel;
        @FXML private TextField customersModifyNameLabel;
        @FXML private TextField customersModifyPhoneLabel;
        @FXML private TextField customersModifyAddressLabel;
        @FXML private TextField customersModifyPostalLabel;

        /** Lambda expression that implements the getErrorMessage method of the Alerts interface.
         * It takes a string representing a field name and returns an error message indicating
         * that the particular field must not be empty.
         */
        public  ErrorMessage errorMessage = (String s) -> "ERROR: The " + s + " must not be empty";


        /**
         * This is the method to return to the Customers screen when the user clicks the Cancel button. No inputted information is saved.
         * @param event the user clicks the Cancel button on the CustomersModify screen
         * @throws IOException
         */
        @FXML void onActionCancel(ActionEvent event) throws IOException {
            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/CustomersAA.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }
        /**
         * Displays an alert dialog to the user.
         * @param alertType Type of alert (e.g., WARNING, CONFIRMATION).
         * @param title Title of the alert dialog.
         * @param content The message to display in the alert dialog.
         */
        private void showAlert(Alert.AlertType alertType, String title, String content) {
            Alert alert = new Alert(alertType);
            alert.setTitle(title);
            alert.setContentText(content);
            alert.showAndWait();
        }
        /**
         * Handles the save action when the user attempts to modify a customer's details.
         * Validates input fields, updates the customer information in the database,
         * and navigates back to the customer overview screen.
         *
         * @param event the event that triggered the save action.
         */
        @FXML
        void onActionSave(ActionEvent event) {
            try {
                int customerID = Integer.parseInt(customersModifyIDLabel.getText());
                String customerName = customersModifyNameLabel.getText();
                String customerAddress = customersModifyAddressLabel.getText();
                String postalCode = customersModifyPostalLabel.getText();
                String customerPhone = customersModifyPhoneLabel.getText();
                Timestamp lastUpdate = Timestamp.valueOf(LocalDateTime.now());
                String lastUpdateBy = Globals.userName;
                FLD division = divisionCombo.getValue();

                if (customerName.isEmpty()) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", errorMessage.getErrorMessage("name"));
                    return;
                }

                if (customerAddress.isEmpty()) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The address must not be empty");
                    return;
                }

                if (postalCode.isEmpty()) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The postal code must not be empty");
                    return;
                }

                if (customerPhone.isEmpty()) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The phone must not be empty");
                    return;
                }

                if (division == null) {
                    showAlert(Alert.AlertType.WARNING, "Warning Dialog", "ERROR: The division must not be empty");
                    return;
                }

                int Division_ID = division.getDivision_ID();
                CustomerD.modifyCustomer(customerID, customerName, customerAddress, postalCode, customerPhone, lastUpdate, lastUpdateBy, Division_ID);
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/CustomersAA.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        /**
         * This is the method to set the divisionCombo combo box with only the divisions for only the specific country when the user selects a country from the countryCombo combo box.
         * @param event the user selects a country from the countryCombo combo box
         * @throws SQLException
         */
        @FXML void onActionCountryCombo(ActionEvent event) throws SQLException {
            divisionCombo.setValue(null);
            Country C = countryCombo.getValue();
            divisionCombo.setItems(DivisionD.getDiv(C.getCountry_ID()));
        }

        /**
         * Receives the selected customer from another controller/screen,
         * making it available for modification in this controller.
         * This method is typically called before switching to the modify customer screen.
         *
         * @param customer the customer selected for modification.
         */
        public static void receiveSelectedCustomer(Customers customer) {
            selectedCustomer = customer;
        }

        /**
         * This is the method to set the combo boxes with all appropriate values, set the combo boxes to select the data from the modified customer, and populate all fields with the data from the modified customer.
         * @param url
         * @param resourceBundle
         */
        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
            try {
                divisionCombo.setValue(DivisionD.getDivFromDivID(selectedCustomer.getDivision_ID()));
                FLD selectedDivision = DivisionD.getDivision(divisionCombo.getValue());
                selectedCountryID = selectedDivision.getCOUNTRY_ID();
                selectedCountry = CountryD.getCountryFromCountryID(selectedCountryID);
                countryCombo.setValue(selectedCountry);
                Country C = countryCombo.getValue();
                divisionCombo.setItems(DivisionD.getDiv(C.getCountry_ID()));
                countryCombo.setItems(CountryD.getAllCountries());
            } catch (Exception e) {
                e.printStackTrace();
            }

            customersModifyIDLabel.setText(Integer.toString(selectedCustomer.getCustomerId()));
            customersModifyNameLabel.setText(selectedCustomer.getCustomerName());
            customersModifyAddressLabel.setText(selectedCustomer.getCustomerAddress());
            customersModifyPhoneLabel.setText(selectedCustomer.getCustomerPhone());
            customersModifyPostalLabel.setText(selectedCustomer.getPostalCode());
        }
    }

